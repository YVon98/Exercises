package com.save.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.save.entity.Menu;
import com.save.entity.Orders;
import com.save.entity.Users;
import com.save.repository.OrdersRepository;

	@Service
public class OrdersService {
	@Autowired
	OrdersRepository repo;
	
	public Orders add(Menu menu, int quantity, Users user, boolean status) {
		
		Orders detail = new Orders();
		detail.setMenu(menu);
		detail.setQuantity(quantity);
		detail.setSubTotal(detail.getSubTotal());
		detail.setStatus(status);
		
		Optional<Orders> exist = repo.findExist(detail);
		if(exist.isPresent()) {
			System.out.println("the order details has exist");
			exist.get();
		}
		return repo.save(detail);
	}
	

}
