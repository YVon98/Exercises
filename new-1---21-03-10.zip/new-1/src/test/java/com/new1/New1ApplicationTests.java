package com.new1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class New1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
