package com.new1;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
//@Transactional
//public class AppRoleDAO {
// 
//    @Autowired
//    private EntityManager entityManager;
// 
//    public List<String> getRoleNames(Long userId) {
//        String sql = "Select ur.appRole.roleName from " + UserRole.class.getName() + " ur " //
//                + " where ur.appUser.userId = :userId ";
// 
//        Query query = this.entityManager.createQuery(sql, String.class);
//        query.setParameter("userId", userId);
//        return query.getResultList();
//    }
public interface AppRoleDAO extends CrudRepository<AppRole, Long> {
	@Query(value = "Select ur.appRole.roleName from UserRole ur where ur.appUser.userId = :userId", nativeQuery = true)
	public List<String> getRoleNames(Long userId);

}
