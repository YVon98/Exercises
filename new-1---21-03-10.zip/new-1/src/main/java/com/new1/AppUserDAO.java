package com.new1;


import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
//@Transactional
//public class AppUserDAO {
// 
//    @Autowired
//    private EntityManager entityManager;
// 
//    public AppUser findUserAccount(String userName) {
//        try {
//            String sql = "Select e from " + AppUser.class.getName() + " e " //
//                    + " Where e.userName = :userName ";
// 
//            Query query = entityManager.createQuery(sql, AppUser.class);
//            query.setParameter("userName", userName);
// 
//            return (AppUser) query.getSingleResult();
//        } catch (NoResultException e) {
//            return null;
//        }
//    }
public interface AppUserDAO extends CrudRepository<AppUser, Long> {
	@Query(value="Select e from AppUser e where e.username = :userName", nativeQuery = true)
	public AppUser findUserAccount(String userName);

}
