package com.new1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class New1Application {

	public static void main(String[] args) {
		SpringApplication.run(New1Application.class, args);
	}

}
