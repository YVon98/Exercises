package com.downloadFile1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DownloadFile1Application {

	public static void main(String[] args) {
		SpringApplication.run(DownloadFile1Application.class, args);
	}

}
