package com.downloadFile1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DownloadFile1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
