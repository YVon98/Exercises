package com.login.config;

public class WebSecurityConfig {

}
