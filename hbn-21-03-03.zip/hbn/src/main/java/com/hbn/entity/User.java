package com.hbn.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Users")
@Data
public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String password;
	private String role;
	private boolean block;

	@OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
	// mappeb by phai giong voi ten khai bao bien khoa ngoai ben Album
	private List<Album> albums;

	@OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
	// mappeb by phai giong voi ten khai bao bien khoa ngoai ben Album
	private List<Song> playlist;

	/// Constructor

	public User(int id, String name, String password, String role, boolean block) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.role = role;
		this.block = block;
	}

	public User() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public boolean isBlock() {
		return block;
	}

	public void setBlock(boolean block) {
		this.block = block;
	}

	public List<Album> getAlbums() {
		return albums;
	}

	public void setAlbums(List<Album> albums) {
		this.albums = albums;
	}
	
}
