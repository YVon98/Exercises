package com.hbn.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hbn.dao.UserRepository;
import com.hbn.entity.User;

@Service
public class UserService  {

	@Autowired
	UserRepository userRepo;

	// add user
	public User addUser(User user) {
		return userRepo.save(user);

	}

	// edit user
	public User editUser(int id, User userDetail) {
		Optional<User> hadUser = userRepo.findById(id);
		if (hadUser.isPresent()) {
			User user = hadUser.get();
			user.setName(userDetail.getName());
			user.setPassword(userDetail.getName());
			user.setRole(userDetail.getRole());
			return userRepo.save(user);
		}
		return null;
	}

	// delete user
	public void deleteUser(int id) {
		userRepo.deleteById(id);
	}

	
}
