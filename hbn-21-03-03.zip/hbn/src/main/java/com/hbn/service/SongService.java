package com.hbn.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hbn.dao.SongRepository;
import com.hbn.entity.Song;

@Service
public class SongService {
	@Autowired
	SongRepository songRepo;
	
	//add
	public Song add(Song song) {
		return songRepo.save(song);
	}
	//edit
	
	public Song edit(int id, Song songDetail) {
		Optional<Song> hasSong = songRepo.findById(id);
		if(hasSong.isPresent()) {
			Song song = hasSong.get();
			song.setName(songDetail.getName());
			song.setArtist(songDetail.getArtist());
			song.setYear(songDetail.getYear());
			song.setAlbum(songDetail.getAlbum());
			return songRepo.save(song);
		}
		return null;
	}
	//delete
	public void delete(int id) {
		songRepo.deleteById(id);;
	}
}
