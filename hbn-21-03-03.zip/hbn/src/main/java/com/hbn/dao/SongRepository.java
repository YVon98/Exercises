package com.hbn.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hbn.entity.Song;

@Repository
public interface SongRepository extends JpaRepository<Song, Integer> {

}
