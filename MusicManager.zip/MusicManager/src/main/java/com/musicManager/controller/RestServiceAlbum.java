package com.musicManager.controller;

public class RestServiceAlbum {

}
