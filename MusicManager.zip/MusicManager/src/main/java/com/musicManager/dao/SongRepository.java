package com.musicManager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.musicManager.entity.Song;

public interface SongRepository extends JpaRepository<Song, Integer> {

}
