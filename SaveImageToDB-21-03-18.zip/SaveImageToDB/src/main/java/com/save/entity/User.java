package com.save.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_user;
	private String user_name;
	private String pass;
	
	private Role Role;

	@JsonIgnore
	@OneToMany(mappedBy = "user")
	private Order order;

}
