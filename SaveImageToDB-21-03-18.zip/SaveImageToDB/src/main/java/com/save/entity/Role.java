package com.save.entity;

public class Role {
	private Long id;
	private String name;

}
