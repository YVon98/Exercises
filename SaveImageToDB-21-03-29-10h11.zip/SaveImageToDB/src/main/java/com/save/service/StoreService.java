package com.save.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.save.entity.Store;
import com.save.repository.StoreRepository;

@Service
public class StoreService {

	@Autowired
	private StoreRepository storeRepository;
	
	
	public List<Store> getAll(){
		return (List<Store>) storeRepository.findAll();
	}
	
	public Optional<Store> getById(Long id) {
		return storeRepository.findById(id);
	}

	public Store add(Store storeDetails) {

		Optional<Store> store1 = storeRepository.findStoreDetail(storeDetails);
		
		if (store1.isPresent()) {
			System.out.println("the store has Exist");
			return store1.get();
		} else {
			storeDetails.setDate(new Date());
			
			Store store = new Store();
			
			BeanUtils.copyProperties(storeDetails, store);
			
			return storeRepository.save(store);
		}
	}
	
	// edit

		public Store edit(Long id, Store storeDetail) {
			Optional<Store> hasStore = storeRepository.findById(id);
			if (hasStore.isPresent()) {
				Store store = hasStore.get();
				store.setName(storeDetail.getName());
				store.setPhone(storeDetail.getPhone());
				store.setStatus(storeDetail.isStatus());
				store.setDate(new Date());
				
				return storeRepository.save(store);
			}
			return null;
		}

		// delete
		public void delete(Long id) {
			storeRepository.deleteById(id);
		}

}
