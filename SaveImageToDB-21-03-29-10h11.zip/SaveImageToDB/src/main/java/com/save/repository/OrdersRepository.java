package com.save.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Repository;

import com.save.entity.Orders;

@Repository
public interface OrdersRepository extends CrudRepository<Orders, Long> {

//	@Query("SELECT d FROM Orders d " + "WHERE d.menu.id_menu = :#{#detail.menu.id_menu} "
//			+ "AND d.quantity = :#{#detail.quantity}" + " AND d.user.id_user= :#{#detail.user.id_user}")
//	Optional<Orders> findExist(@Param("detail") Orders detail);

	@Query("SELECT d FROM Orders d WHERE d.user.id_user =:id_user")
	List<Orders> findByUserId(@Param("id_user") Long id);
	
	

	@Query("SELECT d FROM Orders d WHERE d.order_date >=:fdate AND d.order_date <=:tdate")
	List<Orders> findOrderByDate(@Param("fdate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fdate,
			@Param("tdate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date tdate);

	
	
	@Modifying // to executed update query using JPA
	@Query(value = "DELETE d FROM Orders d WHERE d.id_user =:id_user AND d.id =:id_order", nativeQuery = true)
	@Transactional // Missing this annotation : Executing an update/delete query error
	void deleteOrderByIdAndUserId(@Param("id_user") Long id_user, @Param("id_order") Long id_order);

}
