package com.save.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.save.entity.Users;

@Repository
public interface UserRepository extends CrudRepository<Users, Long>{
	
	@Query("SELECT u FROM Users u WHERE u.user_name = :username")
	public Users getUserByUsername(@Param("username") String username);
	
	@SuppressWarnings("el-syntax")
	@Query("select u from Users u where u.user_name = :#{#user.user_name} ")
	Optional<Users> findUserDetails(@Param("user") Users user);

}
