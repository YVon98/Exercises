package com.save.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.MultipartConfigElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartResolver;

import com.save.entity.Menu;
import com.save.entity.Store;
import com.save.service.MenuService;

@RestController
@RequestMapping("menu")

public class MenuController {

	@Autowired
	MenuService menuService;

	@Bean
	public MultipartConfigElement multipartConfigElement() {
		return new MultipartConfigElement("");
	}

	@Bean
	public MultipartResolver multipartResolver() {
		org.springframework.web.multipart.commons.CommonsMultipartResolver multipartResolver = new org.springframework.web.multipart.commons.CommonsMultipartResolver();
		multipartResolver.setMaxUploadSize(1000000);
		return multipartResolver;
	}

	// get list all menu
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping
	public List<Menu> list() {
		return menuService.list();
	}

	// get menu base on menu id
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/{id}")
	public Optional<Menu> list(@PathVariable("id") Long id) {
		return menuService.getMenuById(id);
	}

	// create a menu
	@PreAuthorize("hasAuthority('ADMIN')")
	@PostMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<?> postMenu(@RequestParam(value = "file") MultipartFile file,
			@RequestParam(value = "name") String name, @RequestParam(value = "price") int price,
			@RequestParam(value = "status") boolean status, @RequestParam(value = "store") Store store)
			throws IOException {
		menuService.saveMenu(file, name, price, status, store);
		return ResponseEntity.ok().build();
	}

	// edit a menu
	@PreAuthorize("hasAuthority('ADMIN')")
	@PutMapping(value = "/{id}", consumes = { "multipart/form-data" })
	public ResponseEntity<?> editMenu(@PathVariable("id") Long id, @RequestParam(value = "file") MultipartFile file,
			@RequestParam(value = "name") String name, @RequestParam(value = "price") int price,
			@RequestParam(value = "status") boolean status) throws IOException {

		menuService.editMenu(id, file, name, price, status);
		return ResponseEntity.ok().build();

	}

	// delete a menu
	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<Menu> deleted(@PathVariable("id") Long id) {
		menuService.deletedMenu(id);
		return ResponseEntity.ok().build();
	}

}
