package com.save.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.save.entity.Orders;
import com.save.service.OrdersService;

@RestController
public class OrdersController {
	@Autowired
	private OrdersService service;

	@PostMapping ("/orders")
	public Orders add(@RequestParam(value="userId") Long id_user, @Valid @RequestBody Orders orders){
		return service.add(id_user, orders);
		
	}

}
