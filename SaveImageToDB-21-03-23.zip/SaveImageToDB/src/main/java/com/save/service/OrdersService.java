package com.save.service;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.save.entity.Orders;
import com.save.entity.Users;
import com.save.repository.OrdersRepository;
import com.save.repository.UserRepository;

@Service
public class OrdersService {
	@Autowired
	private OrdersRepository ordersRepository;

	@Autowired
	private UserRepository userRepository;

	public Orders add(Long id_user, Orders order) {

		Optional<Users> hasUser = userRepository.findById(id_user);
		if (hasUser.isPresent()) {
			order.setUser(hasUser.get());
			order.setOrder_date(new Date());
			order.setSubTotal(order.getSubTotal());

			ordersRepository.save(order);
		}

		return null;
	}

}
