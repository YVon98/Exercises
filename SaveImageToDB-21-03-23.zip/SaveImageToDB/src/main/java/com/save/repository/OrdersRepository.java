package com.save.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.save.entity.Orders;

@Repository("orderDetail")
public interface OrdersRepository extends CrudRepository<Orders, Long> {

	@Query("SELECT d FROM Orders d "
			+ "WHERE d.menu.id_menu = :#{#detail.menu.id_menu} "
			+ "AND d.quantity = :#{#detail.quantity}"
			+ " AND d.user.id_user= :#{#detail.user.id_user}")
	Optional<Orders> findExist(@Param("detail") Orders detail);

}
