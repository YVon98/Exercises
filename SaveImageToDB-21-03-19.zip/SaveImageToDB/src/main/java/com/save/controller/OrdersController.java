package com.save.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.save.entity.Orders;
import com.save.service.OrdersService;

@RestController
@RequestMapping("/order")
public class OrdersController {
	
	@Autowired OrdersService ordersService;
	
	///list all order
	@GetMapping
	public ResponseEntity<?> list(){
		return ResponseEntity.ok(ordersService.listAll());
	}
	
	@GetMapping("/date")
	public ResponseEntity<?> listDate(@Valid @Param("startDate") Date startDate, @Param("endDate") Date endDate){
		return ResponseEntity.ok(ordersService.listByDate(startDate, endDate));
	}
	
	@PostMapping
	public ResponseEntity<?> addOrder(@Valid @RequestBody Orders order){
		return ResponseEntity.ok(ordersService.addOrder(order));
	}
	
	
	

}
