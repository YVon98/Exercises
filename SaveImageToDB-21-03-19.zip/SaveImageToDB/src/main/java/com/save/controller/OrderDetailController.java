package com.save.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.save.entity.Menu;
import com.save.entity.Orders;
import com.save.service.OrderDetailService;

@RestController
@RequestMapping("/orderDetail")
public class OrderDetailController {
	@Autowired
	private OrderDetailService service;

	@PostMapping
	public ResponseEntity<?> add(@RequestParam(value = "menu") Menu menu,
			@RequestParam(value = "quantity") int quantity, @RequestParam(value = "orders") Orders orders) {
		return ResponseEntity.ok(service.add(menu, orders, quantity));
	}

}
