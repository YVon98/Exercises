package com.save.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.save.entity.Menu;
import com.save.entity.OrderDetail;
import com.save.entity.Orders;
import com.save.repository.OrderDetailsRepository;

	@Service
public class OrderDetailService {
	@Autowired
	OrderDetailsRepository repo;
	
	public OrderDetail add(Menu menu, Orders order, int quantity) {
		
		OrderDetail detail = new OrderDetail();
		detail.setMenu(menu);
		detail.setOrder(order);
		detail.setQuantity(quantity);
		
		Optional<OrderDetail> exist = repo.findExist(detail);
		if(exist.isPresent()) {
			System.out.println("the order details has exist");
			exist.get();
		}
		return repo.save(detail);
	}
	

}
