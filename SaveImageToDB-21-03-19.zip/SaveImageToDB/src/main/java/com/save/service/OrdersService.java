package com.save.service;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.save.entity.OrderDetail;
import com.save.entity.Orders;
import com.save.repository.OrderDetailsRepository;
import com.save.repository.OrdersRepository;

@Service
public class OrdersService {
	@Autowired
	private OrdersRepository ordersRepository;

	@Autowired
	private OrderDetailsRepository orderDetailsRepository;

	//// list all order
	public List<Orders> listAll() {
		return (List<Orders>) ordersRepository.findAll();
	}

	///// List order by date:
	public List<Orders> listByDate(Date startDate, Date endDate) {
		return ordersRepository.findByDate(startDate, endDate);

	}

	/// add order
	@SuppressWarnings("unchecked")
	public Orders addOrder(Orders order) {

		OrderDetail orderDetail =  (OrderDetail) order.getOrderDetails();

		createOrderDetail(orderDetail);

		Orders o = new Orders();
		o.setUser(order.getUser());
		o.setOrderDetails((List<OrderDetail>) orderDetail);
		o.setStatus(order.isStatus());
		o.setOrder_date(new Date());

		BeanUtils.copyProperties(order, o);

		return ordersRepository.save(o);
	}

	public void createOrderDetail(OrderDetail detail) {

		orderDetailsRepository.save(detail);

	}

}
