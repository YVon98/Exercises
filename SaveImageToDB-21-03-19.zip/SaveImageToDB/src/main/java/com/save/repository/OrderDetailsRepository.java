package com.save.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.save.entity.OrderDetail;

@Repository
public interface OrderDetailsRepository extends CrudRepository<OrderDetail, Long> {

	@Query("SELECT d FROM OrderDetail d "
			+ "WHERE d.menu.id_menu = :#{#detail.menu.id_menu} "
			+ "AND d.quantity = :#{#detail.quantity}")
	Optional<OrderDetail> findExist(@Param("detail") OrderDetail detail);

}
