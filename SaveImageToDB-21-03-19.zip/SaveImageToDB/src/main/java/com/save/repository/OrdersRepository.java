package com.save.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.save.entity.Orders;

@Repository
public interface OrdersRepository extends CrudRepository<Orders, Long>{
	
	@Query ("SELECT o FROM Orders o WHERE o.order_date BETWEEN :startDate AND :endDate")
	public List<Orders> findByDate(@Param("startDate") Date startDate,@Param("endDate") Date endDate);

}
