package com.save.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_order;

	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn(name = "id_user", nullable = false)
	
	private User user;

	@OneToMany(mappedBy = "order")
	private List<OrderDetail> orderDetails;
	private boolean status;

	@Temporal(TemporalType.DATE)
	private Date order_date;

	public Orders(User user, List<OrderDetail> orderDetails, boolean status) {
		super();
		this.user = user;
		this.orderDetails = orderDetails;
		this.status = status;
		this.order_date = new Date();
	}

	public Orders() {
	}

	public Long getId_order() {
		return id_order;
	}

	public void setId_order(Long id_order) {
		this.id_order = id_order;
	}


	public List<OrderDetail> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(List<OrderDetail> orderDetails) {
		this.orderDetails = orderDetails;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

}
