package com.acf.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acf.entity.Store;
import com.acf.exception.BadRequestException;
import com.acf.exception.ResourceNotFoudException;
import com.acf.repository.StoreRepository;

@Service
public class StoreService {

	@Autowired
	private StoreRepository storeRepository;

	public List<Store> getAll() {
		return (List<Store>) storeRepository.findAll();
	}

	public Store getStoreById(Long id) {
		return storeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoudException("Not exist store with id = " + id)); 
	}

	public Store add(Store storeDetails) {

		Optional<Store> store1 = storeRepository.findStoreDetail(storeDetails);

		if (store1.isPresent()) {
			throw new BadRequestException("The Store has exist");
		} else {
			storeDetails.setDate(new Date());

			Store store = new Store();

			BeanUtils.copyProperties(storeDetails, store);

			return storeRepository.save(store);
		}
	}

	// edit

	public Store edit(Long id, Store storeDetail) {
		Optional<Store> hasStore = Optional.of(storeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoudException("Not exist store with id = " + id)));
		if (hasStore.isPresent()) {
			Store store = hasStore.get();
			store.setName(storeDetail.getName());
			store.setPhone(storeDetail.getPhone());
			store.setStatus(storeDetail.isStatus());
			store.setDate(new Date());

			return storeRepository.save(store);
		}
		return null;
	}

	// delete
	public void delete(Long id) {
//		Store s = storeRepository.findById(id).orElseThrow(() -> new ResourceNotFoudException("Not exist store with id = " + id));
		storeRepository.deleteById(id);
	}

}
