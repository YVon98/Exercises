package com.acf.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.acf.entity.Users;
import com.acf.exception.BadRequestException;
import com.acf.exception.ResourceNotFoudException;
import com.acf.repository.UserRepository;
import com.acf.utils.MyUserDetails;

@Service
public class UsersDetailServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Users user = userRepository.getUserByUsername(username);

		if (user == null) {
			throw new UsernameNotFoundException("Could not find user");
		}

		return new MyUserDetails(user);
	}

	// add user
	public Users addUser(Users userDetail) {
		Optional<Users> user1 = userRepository.findUserDetails(userDetail);
		if (user1.isPresent()) {
			throw new BadRequestException("The User has exist");
		} else {

			userDetail.setPass(bCryptPasswordEncoder.encode(userDetail.getPass()));

			Users user = new Users();

			BeanUtils.copyProperties(userDetail, user);
			return userRepository.save(userDetail);
		}

	}

	// edit user
	public Users editUser(Long id, Users userDetail) {
		Optional<Users> hadUser = Optional.of(userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoudException("Not exist user with id = " + id)));
		if (hadUser.isPresent()) {
			Users user = hadUser.get();
			user.setUser_name(userDetail.getUser_name());
			user.setPass(bCryptPasswordEncoder.encode(userDetail.getPass()));
			user.setRole(userDetail.getRole());
			return userRepository.save(user);
		}
		return null;
	}

	// delete user
	public void deleteUser(Long id) {
//		Users u = userRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoudException("Not exist user with id = " + id));
		userRepository.deleteById(id);
	}

	// get list user
	public List<Users> getListUser() {
		// TODO Auto-generated method stub
		return (List<Users>) userRepository.findAll();
	}

	// get user by id
	public Users getUserById(Long id) {
		return userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoudException("Not exist user with id = " + id));
	}

}
