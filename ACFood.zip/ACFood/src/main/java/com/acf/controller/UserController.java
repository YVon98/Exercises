package com.acf.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acf.entity.Users;
import com.acf.service.UsersDetailServiceImpl;


@RestController
@RequestMapping("/user")



public class UserController {
	@Autowired
	UsersDetailServiceImpl userService;
	
	//getUser
	@GetMapping
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<Users> getListUser(){
		return userService.getListUser();
	}
	
	//get user by id
	
//	@PreAuthorize("hasRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/{id}")
	public Users  getUserById(@PathVariable("id") Long id){
		return userService.getUserById(id);
		
	}

	// add user
//	@PreAuthorize("hasAnyRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@PostMapping(value = "/add")
	
	public ResponseEntity<?> addUser(@Valid @RequestBody Users user) {
		userService.addUser(user);
		return ResponseEntity.ok().build();
	}

	// edit user
//	@PreAuthorize("hasRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@PutMapping(value = "/{id}")
	public ResponseEntity<Users> editUser(@PathVariable("id") Long id, @Valid @RequestBody Users user) {
		return ResponseEntity.ok(userService.editUser(id, user));
	}
	
	//delete user
//	@PreAuthorize("hasRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable("id") Long id){
		userService.deleteUser(id);
		return ResponseEntity.ok().build();
		
	}
	
	


}
