package com.acf.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.acf.entity.Store;

@Repository("store")
public interface StoreRepository extends CrudRepository<Store, Long> {

	@Query(" SELECT s FROM Store s WHERE s.name = :#{#store.name}  ")
	Optional<Store> findStoreDetail(@Param("store") Store store);

}
