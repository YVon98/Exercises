package com.acf.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.acf.entity.Menu;

@Repository
public interface MenuRepository extends CrudRepository<Menu, Long>{
	
	@Query ("SELECT m FROM Menu m WHERE m.name = :#{#menu.name} and m.store.id_store = :#{#menu.store.id_store}")
	public Optional<Menu> findMenuDetail(@Param("menu") Menu menu);

}
