package com.save.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.save.entity.Menu;
import com.save.entity.Orders;
import com.save.service.OrdersService;

@RestController
public class OrdersController {
	@Autowired
	private OrdersService service;

	// list All order
//	@PreAuthorize("hasAnyRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/orders")
	public List<Orders> getAllOrder() {
		return service.listAllOrders();
	}

	// list order by user id
//	@PreAuthorize("hasAnyRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/orders/{id_user}")
	public List<Orders> getOrderByUserId(@PathVariable("id_user") Long id_user) {
		return service.listOrderByUserId(id_user);
	}

	// list order from fdate to tdate
//	@PreAuthorize("hasAnyRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/orders/date")
	public ResponseEntity<List<Orders>> getOrderByDate(
			@Param(value = "fdate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fdate,
			@Param(value = "tdate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date tdate) {
		System.out.println(fdate);
		System.out.println(tdate);
		return ResponseEntity.ok().body(service.listOrderByDate(fdate, tdate));
	}

	// create order
//	@PreAuthorize("hasAnyRole('USER')")
	@PreAuthorize("hasAuthority('USER')")
	@PostMapping(value = "{id_user}/orders", consumes = { "application/xml", "application/json",
			MediaType.APPLICATION_JSON_VALUE })
//	public Orders add(@PathVariable(value = "id_user") Long id_user, @RequestParam(value = "menu") Menu menu,
//			@RequestParam(value = "quantity") int quantity, @RequestParam(value = "status") boolean status) {
//		return service.createOrder(id_user, menu, quantity, status);

//	public Orders add(@PathVariable(value = "id_user") Long id_user, @Valid @RequestBody Orders order) {
//		
//		return service.createOrder(id_user, order);
//	}

	public ResponseEntity<Orders> add(@PathVariable(value = "id_user") Long id_user,
			@Valid @RequestBody ArrayList<Orders> order) {
		for (Orders o : order) {
			service.createOrder(id_user, o);

		}
		return ResponseEntity.ok().build();

	}

	// edit order
//	@PreAuthorize("hasAnyRole('USER')")
	@PreAuthorize("hasAuthority('USER')")
	@PutMapping("{id_user}/orders/{id_order}")
	public Orders edit(@PathVariable(value = "id_user") Long id_user, @PathVariable(value = "id_order") Long id_order,
			@RequestParam(value = "menu") Menu menu, @RequestParam(value = "quantity") int quantity,
			@RequestParam(value = "") boolean status) {
		return service.editOrder(id_user, id_order, menu, quantity, status);
	}

	// deleted order
//	@PreAuthorize("hasAnyRole('USER')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("{id_user}/orders/{id_order}")
	public ResponseEntity<?> deletedOrder(@PathVariable(value = "id_user") Long id_user,
			@PathVariable(value = "id_order") Long id_order) {
		service.deletedOrder(id_user, id_order);
		return ResponseEntity.ok().build();
	}

}
