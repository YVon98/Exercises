package com.save.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.save.entity.Menu;
import com.save.entity.Orders;
import com.save.entity.Users;
import com.save.repository.OrdersRepository;
import com.save.repository.UserRepository;

@Service
public class OrdersService {
	@Autowired
	private OrdersRepository ordersRepository;

	@Autowired
	private UserRepository userRepository;

	/// list all order
	public List<Orders> listAllOrders() {
		return (List<Orders>) ordersRepository.findAll();
	}

	// list order by id_user
	public List<Orders> listOrderByUserId(Long id_user) {
		return ordersRepository.findByUserId(id_user);
	}

	// list order by date
	public List<Orders> listOrderByDate(Date fdate, Date tdate) {
		return ordersRepository.findOrderByDate(fdate, tdate);
	}

	// create an order
//	public Orders createOrder(Long id_user, Menu menu, int quantity, boolean status) {
//
//		Optional<Users> hasUser = userRepository.findById(id_user);
//		if (hasUser.isPresent()) {
//			Users user = hasUser.get();
//
//			Orders order = new Orders();
//
//			order.setUser(user);
//			order.setMenu(menu);
//			order.setQuantity(quantity);
//			order.setOrder_date(new Date());
//			order.setSubTotal(order.getSubTotal());
//			order.setStatus(status);
//
//			ordersRepository.save(order);
//		}
//		return null;
//	}
	public  Orders createOrder(Long id_user, Orders detail) {
		System.out.println(detail.getMenu().getPrice());
		Optional<Users> hasUser = userRepository.findById(id_user);
		if (hasUser.isPresent()) {
			Users user = hasUser.get();
			detail.setUser(user);
			detail.setMenu(detail.getMenu());
			detail.setSubTotal(detail.getSubTotal());
			detail.setOrder_date(new Date());
			ordersRepository.save(detail);
		}
		return null;
	}
//	public Collection<Orders> createOrder(Long id_user, ArrayList<Orders> detail) {
//
//		Optional<Users> hasUser = userRepository.findById(id_user);
//		if (hasUser.isPresent()) {
//			Users user = hasUser.get();
//			Orders order = new Orders();
//			order.setUser(user);
//			order.setOrder_date(new Date());
//			for (int i = 0; i < detail.size(); i++) {
//				order.setMenu(detail.get(i).getMenu());
//				order.setQuantity(detail.get(i).getQuantity());
//
//				order.setSubTotal(detail.get(i).getSubTotal());
//				order.setStatus(detail.get(i).isStatus());
//
//				ordersRepository.save(order);
//			}
//
//		}
//		return null;
//	}

	// edit an order
	public Orders editOrder(Long id_user, Long id_order, Menu menu, int quantity, boolean status) {
		Optional<Users> hasUser = userRepository.findById(id_user);
		if (hasUser.isPresent()) {
			Users user = hasUser.get();

			Optional<Orders> order = ordersRepository.findById(id_order);

			if (order.isPresent()) {

				Orders o = order.get();
				o.setUser(user);
				o.setMenu(menu);
				o.setQuantity(quantity);
				o.setOrder_date(new Date());
				o.setSubTotal(o.getSubTotal());
				o.setStatus(status);

				return ordersRepository.save(o);
			}
			return null;
		}
		return null;

	}

	/// delete an order
	public void deletedOrder(Long id_user, Long id_order) {
		ordersRepository.deleteOrderByIdAndUserId(id_user, id_order);
	}

}
