package com.save.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.save.entity.Menu;
import com.save.entity.Store;
import com.save.exception.BadRequestException;
import com.save.exception.ResourceNotFoudException;
import com.save.repository.MenuRepository;

@Service
public class MenuService {

	@Autowired
	private MenuRepository menurepository;

	// get all menu
	public List<Menu> list() {
		return (List<Menu>) menurepository.findAll();
	}

	// get a menu base on id_menu

	public Menu getMenuById(Long id) {
		return menurepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoudException("Not exist Menu with id = " + id));
	}

	/// save a menu to store
	public Menu saveMenu(MultipartFile file, String name, int price, boolean status, Store store) {

		
		// create obj to contain the user
		Menu menuDetail = new Menu();
		menuDetail.setName(name);
		menuDetail.setStore(store);

		// compare to db
		Optional<Menu> menu1 = menurepository.findMenuDetail(menuDetail);
		if (menu1.isPresent()) {
			throw new BadRequestException("The menu has exist");
		}

		String filename = file.getOriginalFilename();
		try {
			Menu menu = new Menu(name, price, status, filename.getBytes(), new Date(), store);
			return menurepository.save(menu);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// edit a menu
	public Menu editMenu(Long id, MultipartFile file, String name, int price, boolean status) {
		Optional<Menu> menu1 = Optional.of(menurepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoudException("Not exist menu with id = " + id)));
//		if (menu1.isPresent()) {
			Menu menu = menu1.get();
			String filename = file.getOriginalFilename();
//			try {
				menu.setName(name);
				menu.setPrice(price);
				menu.setStatus(status);
				menu.setImage(filename.getBytes());
				menu.setDate(new Date());

				return menurepository.save(menu);
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//			return null;

//		}
//		return null;
	}

	// delete menu
	public void deletedMenu(Long id) {
//		Menu menu = menurepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoudException("Not exist menu with id = " + id));
		menurepository.deleteById(id);
	}

}
