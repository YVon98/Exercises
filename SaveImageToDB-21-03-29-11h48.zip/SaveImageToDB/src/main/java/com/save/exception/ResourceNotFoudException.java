package com.save.exception;

public class ResourceNotFoudException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ResourceNotFoudException(String message) {
		super(message);
	}
	
	public ResourceNotFoudException (String message, Throwable cause) {
        super(message, cause);
	}

}
