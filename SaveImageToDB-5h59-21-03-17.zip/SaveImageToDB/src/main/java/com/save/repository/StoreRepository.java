package com.save.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.save.entity.Store;
@Repository
public interface StoreRepository extends CrudRepository<Store, Long>{
	
	@Query("select qd from Store qd where qd.name = :#{#store.name} and qd.phone = :#{#store.phone}")
	Optional<Store> findStoreDetails(@Param("store") Store store);

}
