package com.save.service;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.save.entity.Menu;
import com.save.entity.Store;
import com.save.repository.MenuRepository;

@Service
public class MenuService {

	@Autowired
	private MenuRepository menurepository;


//	public Menu save(  MultipartFile file , Menu menuDetails) {
//		String filename = file.getOriginalFilename();
//		try {
//			
////			Menu menu = new Menu(menuDetails.getName(), menuDetails.getPrice(), menuDetails.isStatus(), filename.getBytes(), new Date(), menuDetails.getStore());
//			menuDetails.setImage(filename.getBytes());
//			Menu menu = new Menu();
//			 BeanUtils.copyProperties(menuDetails, menu);
//			
//			return menurepository.save(menu);
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//		
//	}

//	public void saveToDB(MultipartFile file, String name, int price, boolean status) {
//		Menu menu = new Menu();
//		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//		
//		if(fileName.contains(".."))
//		{
//			System.out.println("not a a valid file");
//		}
//		try {
//			menu.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		menu.setName(name);
//		menu.setPrice(price);
//		menu.setStatus(status);
//		menu.setDate(new Date());
//		menurepository.save(menu);
//	}

//	public void save(String file, String name, int price, boolean status) throws IOException {
//		ClassPathResource cr = new ClassPathResource(file);
//		byte[] arrPic = new byte [(int) cr.contentLength()];
//		Menu menu = new Menu(name, price, status, arrPic, new Date());
//		menurepository.save(menu);
//	}

	public Menu save(MultipartFile file, String name, int price, boolean status, Store store) {
		String filename = file.getOriginalFilename();
		try {
			Menu menu = new Menu(name, price, status, filename.getBytes(), new Date(), store);
			return menurepository.save(menu);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

}
