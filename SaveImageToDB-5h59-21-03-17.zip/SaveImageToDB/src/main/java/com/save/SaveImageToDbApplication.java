package com.save;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveImageToDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaveImageToDbApplication.class, args);
	}

}
