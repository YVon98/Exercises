package com.save.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.save.entity.Store;
import com.save.service.StoreService;

@RestController
@RequestMapping ("/store")
public class StoreController {
	@Autowired
	private StoreService storeService;
	
	@PostMapping
	public ResponseEntity<?> addStore(@Valid @RequestBody Store store){
		storeService.add(store);
		return ResponseEntity.ok().build();
	}

}
