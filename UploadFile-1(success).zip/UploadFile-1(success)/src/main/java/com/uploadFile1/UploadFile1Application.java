package com.uploadFile1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan({"UploadFile-1/src/main/java/com/uploadFile1/controller/FileUploadController.java"})
public class UploadFile1Application {

	public static void main(String[] args) {
		SpringApplication.run(UploadFile1Application.class, args);
	}

}
