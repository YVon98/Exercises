package com.save.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.save.entity.Menu;
import com.save.service.MenuService;

@RestController
@RequestMapping("menu")
public class MenuController {

	@Autowired
	MenuService menuService;

//	@PostMapping(value = "/add", consumes = { "multipart/form-data" }, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
//	public ResponseEntity<?> postMenu(@RequestParam(value = "file", required = false) MultipartFile file,
//			@Valid @RequestPart(value = "menu", required = false) Menu menu) {
//		menuService.save(file, menu);
//		return ResponseEntity.ok().build();
//	}

//	@PostMapping(value="/add", consumes = { "multipart/form-data" })
//	public ResponseEntity<Menu> postMenu( @RequestParam MultipartFile mutilpartFile,
//			 @RequestParam String name,  @RequestParam int price,  @RequestParam boolean status , HttpServletRequest request) {
//		
//		menuService.saveToDB(mutilpartFile, name, price, status);
//		return ResponseEntity.ok().build();
//	}

	@PostMapping(value = "/add", consumes = { "multipart/form-data" })
	public ResponseEntity<?> postMenu(@RequestParam(value="file") MultipartFile file, @RequestParam (value="name")String name, @RequestParam (value="price")int price,
			@RequestParam (value="status") boolean status) throws IOException {
		menuService.save(file, name, price, status);
		return ResponseEntity.ok().build();
	}

}
