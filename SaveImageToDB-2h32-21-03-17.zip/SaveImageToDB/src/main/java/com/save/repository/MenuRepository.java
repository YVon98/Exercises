package com.save.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.save.entity.Menu;

@Repository
public interface MenuRepository extends JpaRepository<Menu, Long>{

}
