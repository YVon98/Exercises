package com.save.dto;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class MenuDto {
	
	private Long id_menu;
	private String name;
	private int price;
	private boolean status;
	private MultipartFile image;
	private Date date;
	
	
	public MenuDto() {
		super();
	}


	public MenuDto(String name, int price, boolean status, MultipartFile image, Date date) {
		super();
		this.name = name;
		this.price = price;
		this.status = status;
		this.image = image;
		this.date = date;
	}


	public Long getId_menu() {
		return id_menu;
	}


	public void setId_menu(Long id_menu) {
		this.id_menu = id_menu;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}


	public MultipartFile getImage() {
		return image;
	}


	public void setImage(MultipartFile image) {
		this.image = image;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}
	
	///khi them store thi Phan store se dc luu duoi dang lop doundary cua no
	
	
	

}
