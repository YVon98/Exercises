package com.exercises;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

//@Entity
//@Table(name="cart")
public class Cart {
//	@Id
//	@GeneratedValue
	private int id;
	
//	@Temporal(TemporalType.DATE)
	private Date datecreation;
	
//	@OneToMany (mappedBy = "cart" )
	private List<CartItem> items;
	
//	@Column
	private double total;

	public Cart() {
		items = new ArrayList<CartItem>();
		total = 0;
	}

	// lay san pham trong danh sach gio hang
	public CartItem getItem(Product product) {
		for (CartItem item : items) {
			if (item.getProduct().getId() == product.getId()) {
				return item;
			}
		}
		return null;
	}

	// lay danh sach tat ca item
	public List<CartItem> getItems() {
		return items;
	}

	// lay so luong
	public int getItemCount() {
		return items.size();
	}

	// them item
	public void addItem(CartItem item) {
		addItem(item.getProduct(), item.getQuantity());
	}

	// them item voi so luong cho truoc
	public void addItem(Product product, int quantity) {
		CartItem item = getItem(product);
		// neu ton tai cong so luong
		if (item != null) {
			item.setQuantity(item.getQuantity() + quantity);
		} else {// khong ton tai tao moi
			item = new CartItem(product);
			item.setQuantity(quantity);
			items.add(item);
		}
	}

	public void updateItem(Product product, int quantity) {
		CartItem item = getItem(product);
		if (item != null) {
			item.setQuantity(quantity);
		}
	}

	public void removeItem(Product product) {
		CartItem item = getItem(product);
		if (item != null) {
			items.remove(item);
		}
	}

	public void clear() {
		items.clear();
		total = 0;
	}

	public boolean isEmpty() {
		return items.isEmpty();
	}
	
	public double getTotal() {
		total =0;
		for(CartItem item : items) {
			total+= item.getSubTotal();
		}
		
		return total;
	}

}