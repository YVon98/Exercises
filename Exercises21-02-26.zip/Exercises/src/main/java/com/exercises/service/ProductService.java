package com.exercises.service;

//import java.io.File;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.exercises.Product;
import com.exercises.repository.ProductRepository;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

@Service
public class ProductService {
	@Autowired
	private ProductRepository repo;

	// the delimiter to use for separating entries
	private static final char DEFAULT_SEPARATOR = ',';
	// the character to use for quoted elements
	private static final char DEFAULT_QUOTE = '"';
	// the line number to skip for start reading
	private static final int NUM_OF_LINE_SKIP = 1;
	
	//lay danh sach san pham theo keyword co phan trang
	public Page<Product> listAll(int pageNumber, String keyword) {
		Sort sort = Sort.by("name").ascending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort);
		if (keyword == null) {
			return repo.findAll(pageable);
		}
		return repo.findAll(keyword, pageable);
	}
	
	// lay danh sach pham theo keyword
	public List<Product> listAll(String keyword) {
		if (keyword != null) {
			return repo.search(keyword);
		}
		return repo.findAll();
	
	}
	
	// luu san pham
	public void saveProduct(Product product) {
		repo.save(product);
	}

	//lay san pham dua tren id
	public Product get(int id) {
		return repo.findById(id).get();
	}

	//xoa san pham
	public void delete(int id) {
		repo.deleteById(id);
	}

	//luu danh sach san pham
	public void saveAll(List<Product> products) {
		repo.saveAll(products);
	}

	//import file csv
	public void importCsv(MultipartFile file) throws IllegalStateException, IOException {
		ColumnPositionMappingStrategy<Product> strategy = new ColumnPositionMappingStrategy<Product>();
		strategy.setType(Product.class);
		String[] columns = new String[] { "name", "brand", "madein", "price" };
		strategy.setColumnMapping(columns);
		Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
		CsvToBean<Product> csvToBean = new CsvToBeanBuilder<Product>(reader).withType(Product.class)
				.withMappingStrategy(strategy).withSeparator(DEFAULT_SEPARATOR).withQuoteChar(DEFAULT_QUOTE)
				.withSkipLines(NUM_OF_LINE_SKIP).withIgnoreLeadingWhiteSpace(true).build();

		List<Product> products = csvToBean.parse();
		repo.saveAll(products);
	}
	
	//tim san pham dua theo ten
	public Product findByName(String name) {
		Product product = new Product();
		if (product.getName().equals(name)) {
			return get(product.getId());
		}
		return null;
	}

}
