package com.exercises.service;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.exercises.Cart;


@Service
public class CartService {
	// đưa cartrepo và cartitemrepo vào trong đây

	private static final String SESSION_KEY_GIO_HANG = "gioHang";

	//lay ve gio hang
	public Cart getCart(HttpSession session) {
		Cart cart = (Cart) session.getAttribute(SESSION_KEY_GIO_HANG);
		if (cart == null) {
			cart = new Cart();
			setCart(session, cart);
		}
		return cart;
	}

	//thiet lap mot gio hang
	public void setCart(HttpSession session, Cart cart) {
		session.setAttribute(SESSION_KEY_GIO_HANG, cart);
	}

	//xoa 1 gio hang
	public void removeCart(HttpSession session) {
		session.removeAttribute(SESSION_KEY_GIO_HANG);

	}
}
