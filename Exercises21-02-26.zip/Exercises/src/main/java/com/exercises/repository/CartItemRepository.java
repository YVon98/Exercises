package com.exercises.repository;

public interface CartItemRepository {

}
