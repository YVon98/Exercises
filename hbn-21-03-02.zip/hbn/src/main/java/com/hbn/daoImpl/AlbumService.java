package com.hbn.daoImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hbn.dao.AlbumRepository;
import com.hbn.entity.Album;

@Service
public class AlbumService {
	
	@Autowired 
	AlbumRepository albumRepo;
	
	//add album:
	public Album add(Album album) {
		return albumRepo.save(album);
	}
	//edit:
	public Album edit(int id, Album albumDetail) {
		Optional<Album> hasAlbum = albumRepo.findById(id);
		if(hasAlbum.isPresent()) {
			Album album = hasAlbum.get();
			album.setName(albumDetail.getName());
			return albumRepo.save(album);
		}
		return null;
	}
	//delete:
	public void delete(int id) {
		albumRepo.deleteById(id);
	}
	

}
