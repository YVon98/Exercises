package com.hbn.cotroller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hbn.daoImpl.AlbumService;
import com.hbn.entity.Album;

@RestController
@RequestMapping("/album")
public class RestServiceAlbum {
	@Autowired 
	AlbumService albumService;
	
	@PostMapping ("/add")
	public ResponseEntity<Album> add(@Valid @RequestBody Album album) {
		return ResponseEntity.ok(albumService.add(album));
		
	}
	
	@PutMapping ("/{id}")
	public ResponseEntity<Album> edit(@PathVariable("id") int id, @Valid @RequestBody Album album){
		return ResponseEntity.ok(albumService.edit(id, album));
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delet(@PathVariable("id") int id){
		albumService.delete(id);
		return ResponseEntity.ok().build();
		}

}
