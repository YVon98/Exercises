package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Song;
import com.example.demo.repository.SongRepository;


@Service
public class SongService {
	@Autowired
	SongRepository songRepo;
	
	//add
	public Song add(Song songDetail) {
//		Optional<Song> has = songRepo.findByName(songDetail.getName());
//		if (has.isPresent()) {
//			
//		}
		
		
		return songRepo.save(songDetail);
		
		
	}
	//edit
	
	public Song edit(int id, Song songDetail) {
		Optional<Song> hasSong = songRepo.findById(id);
		if(hasSong.isPresent()) {
			Song song = hasSong.get();
			song.setName(songDetail.getName());
			song.setArtist(songDetail.getArtist());
			song.setYear(songDetail.getYear());
			song.setAlbum(songDetail.getAlbum());
			return songRepo.save(song);
		}
		return null;
	}
	//delete
	public void delete(int id) {
		songRepo.deleteById(id);;
	}
}
