package com.save.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.save.entity.Store;
import com.save.service.StoreService;

@RestController
@RequestMapping("/store")



public class StoreController {
	@Autowired
	private StoreService storeService;

//	@PreAuthorize("hasAnyRole('ADMIN')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping
	public List<Store> getStore() {
		return storeService.getAll();
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@PostMapping
	public ResponseEntity<?> addStore(@Valid @RequestBody Store store) {
		return ResponseEntity.ok().body(storeService.add(store));
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<?> edit(@PathVariable("id") Long id, @Valid @RequestBody Store store) {
		return ResponseEntity.ok().body(storeService.edit(id, store));
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("/{id}")
	public void deleted(@PathVariable("id") Long id) {
		storeService.delete(id);
	}

}
