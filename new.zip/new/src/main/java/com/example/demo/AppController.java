package com.example.demo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/user")
public class AppController {
	@Autowired
	UserDetailsServiceImpl userService;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResponseEntity<String> home() {
		return new ResponseEntity<>("Welcome to home page", HttpStatus.OK);
	}

	// add user
	@PostMapping(value = "/add")
	
	public ResponseEntity<?> addUser(@Valid @RequestBody User user) {
		userService.addUser(user);
		return ResponseEntity.ok().build();
	}

	// edit user
	@PutMapping(value = "/{id}")
	@Secured("ROLE_ADMIN")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public ResponseEntity<User> editUser(@PathVariable("id") Long id, @Valid @RequestBody User user) {
		return ResponseEntity.ok(userService.editUser(id, user));
	}
	
	@DeleteMapping("/{id}")
	@Secured("ROLE_ADMIN")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public ResponseEntity<?> deleteUser(@PathVariable("id") Long id){
		userService.deleteUser(id);
		return ResponseEntity.ok().build();
		
	}

}
