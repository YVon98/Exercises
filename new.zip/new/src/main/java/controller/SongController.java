package controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import entity.Song;
import service.SongService;


@RestController
@RequestMapping("/song")
public class SongController {
	@Autowired 
	SongService songService;
	
	@PostMapping("/add")
	public ResponseEntity<Song> add(@Valid @RequestBody Song song){
		return ResponseEntity.ok(songService.add(song));
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Song> edit(@PathVariable("id") int id, @Valid @RequestBody Song song){
		return ResponseEntity.ok(songService.edit(id, song));
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<Song> delete(@PathVariable("id") int id){
		songService.delete(id);
		return ResponseEntity.ok().build();
	}

}
